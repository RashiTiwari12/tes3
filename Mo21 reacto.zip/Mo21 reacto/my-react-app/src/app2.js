import logo from './logo.svg';
import './App.css';
import {Formik, Form, Field} from 'formik';
import { useState } from 'react';
import * as Yup from "yup";

const signupSchema=Yup.object().shape({
  firstname:Yup.string("Invalid firstname type").required("Firstname is required")
  .min(3, "f-Name cannot be less than three chars")
  .max(30, "f-Name is to long"),
  lastname:Yup.string("Invalid lastname type").required("Lastname is required")
  .min(3, "Lastame cannot be less than three chars")
  .max(30, "Lastname is to long"),
  useremail: Yup.string("Invalid email type").email()
  .required("Email is required"),
  userpassword : Yup.string()
  .required("password is required").min(6, "password canot be less than 6 chars"). max(12, "password is too long")
});

function App() {

 const [initialFormValues] =useState({
  firstname:"",
  lastname:"",
  useremail:"",
  userpassword:""
 })
 
 const handleSubmit =(values) => {
  console.log(values)
 }
  return (
    <>
    <div className='main-container'>
  <p>Signup to this formik component</p>
  <Formik validationSchema={signupSchema} initialValues={initialFormValues} onSubmit={handleSubmit}>
   {({errors, touched})=>(
     <Form>
     <label>
       Firstname
       <Field type="text" name="firstname"/>
     </label>
     {errors.firstname && touched.firstname ?( <div>{errors.firstname}</div> ): null}

     <label>
       Lastname
       <Field type="text" name="lastname"/>
     </label>
     {errors.lastname && touched.lastname ?( <div>{errors.lastname}</div> ): null}

     <label>
       Email
       <Field type="email" name="useremail"/>
     </label>
     {errors.useremail && touched.useremail ?( <div>{errors.useremail}</div> ): null}

     <label>
       Password
       <Field type="text" name="userpassword"/>
     </label>
     {errors.userpassword && touched.userpassword ?( <div>{errors.userpassword}</div> ): null}
     
     <button type='submit'>Sign Up</button>
   </Form>
   )}
  </Formik>
    </div>
    </>
    
  );
}

export default App;
