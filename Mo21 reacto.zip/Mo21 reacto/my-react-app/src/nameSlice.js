import {createSlice} from '@reduxjs/toolkit'
const initialState =" v j"
export const nameSlice = createSlice({
    name: 'personName',
    initialState,
    reducers:{
        updateName: (state, action) =>{
            console.log(state)
            console.log(action.payload)
            return action.payload
        }
    }
})
export const {updateName} =nameSlice.actions

export default nameSlice.reducer