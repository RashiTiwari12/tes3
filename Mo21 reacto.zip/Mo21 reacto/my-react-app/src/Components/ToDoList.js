import React from 'react'
import { useNavigate } from 'react-router-dom';

function ToDoList() {
  
    let navigate = useNavigate();
    function logOut(){
        navigate("/Login", true);
    }
    function handleSubmit(e) {
        e.preventDefault()
    }
    return (
        <div className='todo-form'>

            <h2>To-do-list Component</h2>
            <form onSubmit={handleSubmit} className="to-do-list-form">
                <input type="text" />
                <button >Add Task</button>
                <button onClick={logOut} className='login-btn' type="submit">Logout</button>
            </form>
        </div>
      
    )
}
export default ToDoList