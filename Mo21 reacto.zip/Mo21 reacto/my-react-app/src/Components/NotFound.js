import React from 'react'

const NotFound = () => {
  return (
    <div><p>Page not found</p></div>
  )
}

export default NotFound