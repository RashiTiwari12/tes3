import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import LoginDetails from './LoginDetails.json'

function Login() {

    let location = useLocation();
    let navigate = useNavigate();
    console.log(location.pathname)
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });

    const { email, password } = formData

    function handleSubmit(e) {
        e.preventDefault();
        if (LoginDetails.email === email && LoginDetails.password === password) {
            navigate("/", true)
        } else {
            navigate("/invalid", true)
        }

    }

    function handleChange(e) {
        e.preventDefault();
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });

    }

    return (
        <form onSubmit={handleSubmit} className='login-form'>
            <h2>Login-Page</h2>
            <label htmlFor='email'>Email</label>
            <input type="email" name="email" id="email" onChange={handleChange} value={email}></input>
            <label htmlFor='password'>Password</label>
            <input type="password" name="password" id="password" onChange={handleChange} value={password}></input>
            <button className='login-btn' type="submit">Login</button>
        </form>
    )
}

export default Login